# Employee Attendance Monitoring System
**The Eighty First Street Cafe** — Calle Rizal, Baliwag, Bulacan

A Python + Streamlit school project demonstrating object-oriented programming.

## Features
- First-run administrator account setup
- Password hashing using PBKDF2
- Admin and employee roles
- Employee time-in and time-out using server time in Asia/Manila
- Prevention of duplicate active time-ins
- Employee attendance history and working-hour totals
- Admin employee account creation/deactivation
- Admin attendance overview and CSV report export

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## First launch
The first visitor is shown an administrator setup form. Create the manager account with a strong password. The admin can then create employee accounts.

## Project structure
- `models/`: User hierarchy, attendance record, report generator
- `services/`: Authentication and attendance rules
- `database/`: SQLite persistence
- `tests/`: automated unit tests
- `app.py`: Streamlit interface

## OOP concepts
- **Encapsulation:** private fields in `User` and `AttendanceRecord`, exposed through properties.
- **Inheritance:** `Employee` and `Admin` inherit from abstract `User`.
- **Polymorphism:** both subclasses override `dashboard_type`.
- **Abstraction:** `User` is an abstract base class with an abstract property.

## Important deployment note
SQLite is suitable for local development and demonstration. A file stored on an ephemeral cloud filesystem may be lost when an app is restarted or redeployed. Before using this for real employee records, migrate to a persistent hosted database such as PostgreSQL, configure backups, and restrict access appropriately. This is a school-project starter, not a production payroll or HR system.

## Tests
```bash
python -m unittest discover -s tests -v
```
