# UML Class Design

```mermaid
classDiagram
    class User {
      <<abstract>>
      -int __user_id
      -str __username
      -str __full_name
      +user_id
      +username
      +full_name
      +dashboard_type*
    }
    class Employee {
      +dashboard_type
    }
    class Admin {
      +dashboard_type
    }
    class AttendanceRecord {
      -int __record_id
      -int __employee_id
      -str __time_in
      -str __time_out
      -float __working_hours
      +record_id
      +employee_id
      +time_in
      +time_out
      +working_hours
    }
    class DatabaseManager {
      +initialize_database()
      +create_user()
      +get_user_by_username()
      +create_attendance()
      +close_attendance()
      +get_employee_attendance()
      +get_all_attendance()
    }
    class AuthManager {
      +create_user()
      +login()
      +has_any_admin()
    }
    class AttendanceManager {
      +time_in()
      +time_out()
      +get_employee_history()
      +get_all_records()
    }
    class ReportGenerator {
      +get_report_rows()
      +to_csv_bytes()
    }
    User <|-- Employee
    User <|-- Admin
    AuthManager --> DatabaseManager
    AttendanceManager --> DatabaseManager
    ReportGenerator --> DatabaseManager
    AttendanceManager ..> AttendanceRecord
```

The diagram describes the implemented class relationships in this starter version. If classes or methods change during development, update this diagram to match the final code.
