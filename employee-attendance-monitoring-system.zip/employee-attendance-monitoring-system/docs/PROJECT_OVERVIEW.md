# Project Overview

## Problem
Manual attendance recording can take time and make attendance information difficult to organize and review.

## General objective
To develop an Employee Attendance Monitoring System for The Eighty First Street Cafe using Python and a Streamlit interface.

## Specific objectives
1. Allow employees to record time-in and time-out using a mobile-friendly interface.
2. Automatically record the date and time of attendance using the application server's Asia/Manila clock.
3. Calculate completed attendance-session working hours.
4. Allow the administrator to manage employee accounts and review attendance records.
5. Generate downloadable attendance reports.

## Users
- Employee: records attendance and reviews their own history.
- Administrator/manager: creates and deactivates employee accounts, reviews all attendance records, and exports reports.

## Information stored
- User ID: integer
- Username: text
- Full name: text
- Password hash: text
- Role: text
- Active status: boolean/integer
- Attendance record ID: integer
- Employee ID: integer
- Time-in: timestamp text
- Time-out: timestamp text, optional until checkout
- Working hours: decimal number
