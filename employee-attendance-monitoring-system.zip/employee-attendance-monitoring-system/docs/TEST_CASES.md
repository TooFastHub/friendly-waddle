# Test Cases

Run automated tests with `python -m unittest discover -s tests -v`.

| ID | Test | Expected result |
|---|---|---|
| TC01 | Log in with correct employee password | Employee account is returned |
| TC02 | Log in with incorrect password | Login is rejected |
| TC03 | Create duplicate username | Validation error is raised |
| TC04 | Employee time-in | An open attendance record is created |
| TC05 | Employee attempts second time-in | Validation error is raised |
| TC06 | Employee time-out without time-in | Validation error is raised |

Record the actual result and pass/fail status after running the tests on your device. Do not mark tests as passed until they have been executed.
