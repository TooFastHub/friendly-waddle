from datetime import datetime
from zoneinfo import ZoneInfo
from models.attendance_record import AttendanceRecord

class AttendanceManager:
    """Applies attendance rules and calculates elapsed working time."""
    TIMEZONE = ZoneInfo("Asia/Manila")

    def __init__(self, database):
        self._database = database

    @classmethod
    def _now(cls):
        return datetime.now(cls.TIMEZONE)

    def get_open_record(self, employee_id):
        row = self._database.get_open_attendance(employee_id)
        if not row:
            return None
        return AttendanceRecord(row["id"], row["employee_id"], "", row["time_in"])

    def time_in(self, employee_id):
        if self._database.get_open_attendance(employee_id):
            raise ValueError("You are already timed in. Please time out first.")
        now = self._now().isoformat(timespec="seconds")
        record_id = self._database.create_attendance(employee_id, now)
        return AttendanceRecord(record_id, employee_id, "", now)

    def time_out(self, employee_id):
        row = self._database.get_open_attendance(employee_id)
        if not row:
            raise ValueError("You must time in before you can time out.")
        now = self._now()
        start = datetime.fromisoformat(row["time_in"])
        seconds = max(0, (now - start).total_seconds())
        hours = round(seconds / 3600, 2)
        self._database.close_attendance(row["id"], now.isoformat(timespec="seconds"), hours)
        return hours

    def get_employee_history(self, employee_id):
        return self._database.get_employee_attendance(employee_id)

    def get_all_records(self):
        return self._database.get_all_attendance()
