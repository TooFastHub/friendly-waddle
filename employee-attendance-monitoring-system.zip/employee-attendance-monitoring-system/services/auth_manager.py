import hashlib
import hmac
import os
from models.user import Employee, Admin

class AuthManager:
    """Creates accounts and authenticates users with salted password hashes."""
    def __init__(self, database):
        self._database = database

    @staticmethod
    def _hash_password(password, salt=None):
        salt = salt or os.urandom(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
        return salt.hex() + "$" + digest.hex()

    @staticmethod
    def _verify_password(password, stored):
        try:
            salt_hex, digest_hex = stored.split("$", 1)
            candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 200_000)
            return hmac.compare_digest(candidate.hex(), digest_hex)
        except (ValueError, TypeError):
            return False

    def create_user(self, username, full_name, password, role):
        if not username or not full_name or not password:
            raise ValueError("Username, full name, and password are required.")
        if role not in ("admin", "employee"):
            raise ValueError("Invalid account role.")
        if len(password) < 8:
            raise ValueError("Password must contain at least 8 characters.")
        return self._database.create_user(username, full_name, self._hash_password(password), role)

    def login(self, username, password):
        row = self._database.get_user_by_username(username)
        if not row or not row["active"] or not self._verify_password(password, row["password_hash"]):
            return None
        cls = Admin if row["role"] == "admin" else Employee
        return cls(row["id"], row["username"], row["full_name"])

    def has_any_admin(self):
        return self._database.has_admin()
