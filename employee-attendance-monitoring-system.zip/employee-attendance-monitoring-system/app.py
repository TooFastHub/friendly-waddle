import streamlit as st
import pandas as pd
from datetime import datetime
from zoneinfo import ZoneInfo

from database.database_manager import DatabaseManager
from services.auth_manager import AuthManager
from services.attendance_manager import AttendanceManager
from models.user import Employee, Admin
from models.report_generator import ReportGenerator

st.set_page_config(page_title="Eighty First Street Cafe | Attendance", page_icon="🕒", layout="wide")

DB_PATH = st.secrets.get("DB_PATH", "attendance.db") if hasattr(st, "secrets") else "attendance.db"
db = DatabaseManager(DB_PATH)
auth = AuthManager(db)
attendance = AttendanceManager(db)
reports = ReportGenerator(db)

def init_session():
    for key, value in {"user": None, "login_error": ""}.items():
        if key not in st.session_state:
            st.session_state[key] = value

init_session()

def show_setup():
    st.title("Set up your administrator account")
    st.info("This is the first launch. Create the manager account before adding employees.")
    with st.form("first_admin"):
        username = st.text_input("Admin username")
        full_name = st.text_input("Manager full name")
        password = st.text_input("Password", type="password")
        confirm = st.text_input("Confirm password", type="password")
        submitted = st.form_submit_button("Create administrator", type="primary")
    if submitted:
        if not username.strip() or not full_name.strip() or not password:
            st.error("Please complete all fields.")
        elif password != confirm:
            st.error("Passwords do not match.")
        elif len(password) < 8:
            st.error("Use a password with at least 8 characters.")
        else:
            try:
                auth.create_user(username.strip(), full_name.strip(), password, "admin")
                st.success("Administrator created. You can now log in.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))

def show_login():
    st.title("🕒 Employee Attendance Monitoring")
    st.subheader("The Eighty First Street Cafe")
    st.caption("Calle Rizal, Baliwag, Bulacan")
    st.write("Sign in using the account provided by your manager.")
    with st.form("login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Log in", type="primary", use_container_width=True)
    if submitted:
        user = auth.login(username.strip(), password)
        if user:
            st.session_state.user = user
            st.rerun()
        else:
            st.error("Incorrect username or password, or this account is inactive.")

def show_employee(user):
    st.title(f"Welcome, {user.full_name}")
    st.caption("Employee dashboard")
    today = datetime.now(ZoneInfo("Asia/Manila")).date().isoformat()
    current = attendance.get_open_record(user.user_id)
    c1, c2 = st.columns(2)
    c1.metric("Today's date", today)
    c2.metric("Attendance status", "Timed in" if current else "Not timed in")

    if current:
        st.info(f"Your time-in: {current.time_in}")
        if st.button("Time out", type="primary", use_container_width=True):
            try:
                attendance.time_out(user.user_id)
                st.success("Time-out recorded successfully.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
    else:
        if st.button("Time in", type="primary", use_container_width=True):
            try:
                record = attendance.time_in(user.user_id)
                st.success(f"Time-in recorded: {record.time_in}")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))

    st.subheader("My attendance history")
    history = attendance.get_employee_history(user.user_id)
    if history:
        st.dataframe(pd.DataFrame(history), use_container_width=True, hide_index=True)
        total = sum(float(row["working_hours"] or 0) for row in history)
        st.metric("Total recorded working hours", f"{total:.2f} hours")
    else:
        st.info("You do not have attendance records yet.")

def show_admin(user):
    st.title(f"Welcome, {user.full_name}")
    st.caption("Administrator dashboard")
    employees = db.list_users(role="employee", active_only=True)
    records = attendance.get_all_records()
    c1, c2, c3 = st.columns(3)
    c1.metric("Active employees", len(employees))
    c2.metric("Attendance records", len(records))
    today = datetime.now(ZoneInfo("Asia/Manila")).date().isoformat()
    present_today = sum(1 for r in records if str(r["time_in"]).startswith(today))
    c3.metric("Time-ins today", present_today)

    tab1, tab2, tab3 = st.tabs(["Employees", "Attendance records", "Reports"])
    with tab1:
        st.subheader("Add employee")
        with st.form("add_employee"):
            col1, col2 = st.columns(2)
            full_name = col1.text_input("Employee full name")
            username = col2.text_input("Employee username")
            password = st.text_input("Temporary password", type="password")
            submitted = st.form_submit_button("Create employee")
        if submitted:
            try:
                auth.create_user(username.strip(), full_name.strip(), password, "employee")
                st.success("Employee account created.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
        st.subheader("Employee accounts")
        if employees:
            st.dataframe(pd.DataFrame(employees), use_container_width=True, hide_index=True)
            options = {f'{e["full_name"]} (@{e["username"]})': e["id"] for e in employees}
            selected = st.selectbox("Select an employee to deactivate", list(options.keys()))
            if st.button("Deactivate selected employee"):
                db.deactivate_user(options[selected])
                st.success("Employee deactivated.")
                st.rerun()
        else:
            st.info("No employee accounts have been created.")
    with tab2:
        st.subheader("All attendance records")
        if records:
            st.dataframe(pd.DataFrame(records), use_container_width=True, hide_index=True)
        else:
            st.info("No attendance records yet.")
    with tab3:
        st.subheader("Attendance report")
        report_rows = reports.get_report_rows()
        if report_rows:
            df = pd.DataFrame(report_rows)
            st.dataframe(df, use_container_width=True, hide_index=True)
            csv_bytes = reports.to_csv_bytes(report_rows)
            st.download_button("Download CSV report", data=csv_bytes,
                               file_name="attendance_report.csv", mime="text/csv")
        else:
            st.info("There are no records to include in a report.")

if not auth.has_any_admin():
    show_setup()
elif st.session_state.user is None:
    show_login()
else:
    user = st.session_state.user
    with st.sidebar:
        st.title("Eighty First Street Cafe")
        st.write(f"Signed in as **{user.full_name}**")
        st.caption(user.dashboard_type)
        if st.button("Log out", use_container_width=True):
            st.session_state.user = None
            st.rerun()
    if isinstance(user, Admin):
        show_admin(user)
    elif isinstance(user, Employee):
        show_employee(user)
    else:
        st.error("Unsupported account type. Please contact the administrator.")
