class AttendanceRecord:
    """Represents one employee attendance session."""
    def __init__(self, record_id, employee_id, employee_name, time_in, time_out=None, working_hours=0.0):
        self.__record_id = record_id
        self.__employee_id = employee_id
        self.__employee_name = employee_name
        self.__time_in = time_in
        self.__time_out = time_out
        self.__working_hours = float(working_hours or 0.0)

    @property
    def record_id(self): return self.__record_id
    @property
    def employee_id(self): return self.__employee_id
    @property
    def employee_name(self): return self.__employee_name
    @property
    def time_in(self): return self.__time_in
    @property
    def time_out(self): return self.__time_out
    @property
    def working_hours(self): return self.__working_hours
