from abc import ABC, abstractmethod

class User(ABC):
    """Abstract base class shared by all system users."""
    def __init__(self, user_id: int, username: str, full_name: str):
        self.__user_id = int(user_id)
        self.__username = username
        self.__full_name = full_name

    @property
    def user_id(self):
        return self.__user_id

    @property
    def username(self):
        return self.__username

    @property
    def full_name(self):
        return self.__full_name

    @property
    @abstractmethod
    def dashboard_type(self):
        """Return the dashboard role for this user."""
        raise NotImplementedError

class Employee(User):
    @property
    def dashboard_type(self):
        return "Employee"

class Admin(User):
    @property
    def dashboard_type(self):
        return "Administrator"
