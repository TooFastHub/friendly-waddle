import csv
import io
from database.database_manager import DatabaseManager

class ReportGenerator:
    """Creates attendance reports from stored records."""
    def __init__(self, database: DatabaseManager):
        self._database = database

    def get_report_rows(self):
        return self._database.get_all_attendance()

    def to_csv_bytes(self, rows):
        output = io.StringIO()
        fields = ["employee_name", "username", "time_in", "time_out", "working_hours"]
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue().encode("utf-8-sig")
