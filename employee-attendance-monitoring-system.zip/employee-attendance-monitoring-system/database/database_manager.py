import sqlite3
from pathlib import Path

class DatabaseManager:
    """Handles SQLite connections and database operations."""
    def __init__(self, db_path="attendance.db"):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True) if self.db_path != ":memory:" else None
        self.initialize_database()

    def connect(self):
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def initialize_database(self):
        with self.connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    full_name TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('admin','employee')),
                    active INTEGER NOT NULL DEFAULT 1
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    employee_id INTEGER NOT NULL,
                    time_in TEXT NOT NULL,
                    time_out TEXT,
                    working_hours REAL NOT NULL DEFAULT 0,
                    FOREIGN KEY(employee_id) REFERENCES users(id)
                )
            """)
            conn.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS one_open_attendance_per_employee
                ON attendance(employee_id) WHERE time_out IS NULL
            """)

    def create_user(self, username, full_name, password_hash, role):
        try:
            with self.connect() as conn:
                cursor = conn.execute(
                    "INSERT INTO users(username, full_name, password_hash, role) VALUES(?,?,?,?)",
                    (username, full_name, password_hash, role))
                return cursor.lastrowid
        except sqlite3.IntegrityError as exc:
            raise ValueError("That username is already in use.") from exc

    def get_user_by_username(self, username):
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            return dict(row) if row else None

    def has_admin(self):
        with self.connect() as conn:
            return conn.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone() is not None

    def list_users(self, role=None, active_only=False):
        query = "SELECT id, username, full_name, role, active FROM users WHERE 1=1"
        params = []
        if role:
            query += " AND role=?"; params.append(role)
        if active_only:
            query += " AND active=1"
        query += " ORDER BY full_name"
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(query, params).fetchall()]

    def deactivate_user(self, user_id):
        with self.connect() as conn:
            conn.execute("UPDATE users SET active=0 WHERE id=? AND role='employee'", (user_id,))

    def create_attendance(self, employee_id, time_in):
        try:
            with self.connect() as conn:
                cursor = conn.execute(
                    "INSERT INTO attendance(employee_id, time_in) VALUES(?,?)",
                    (employee_id, time_in))
                return cursor.lastrowid
        except sqlite3.IntegrityError as exc:
            raise ValueError("You already have an active time-in. Please time out first.") from exc

    def get_open_attendance(self, employee_id):
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM attendance WHERE employee_id=? AND time_out IS NULL ORDER BY id DESC LIMIT 1",
                (employee_id,)).fetchone()
            return dict(row) if row else None

    def close_attendance(self, record_id, time_out, hours):
        with self.connect() as conn:
            cursor = conn.execute(
                "UPDATE attendance SET time_out=?, working_hours=? WHERE id=? AND time_out IS NULL",
                (time_out, hours, record_id))
            if cursor.rowcount != 1:
                raise ValueError("This attendance session is already closed or no longer exists.")

    def get_employee_attendance(self, employee_id):
        query = """SELECT a.id, u.full_name AS employee_name, a.time_in, a.time_out,
                   a.working_hours FROM attendance a JOIN users u ON u.id=a.employee_id
                   WHERE a.employee_id=? ORDER BY a.time_in DESC"""
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(query, (employee_id,)).fetchall()]

    def get_all_attendance(self):
        query = """SELECT u.full_name AS employee_name, u.username, a.time_in, a.time_out,
                   a.working_hours FROM attendance a JOIN users u ON u.id=a.employee_id
                   ORDER BY a.time_in DESC"""
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(query).fetchall()]
