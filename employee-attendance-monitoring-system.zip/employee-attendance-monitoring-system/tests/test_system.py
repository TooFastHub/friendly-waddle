import os
import tempfile
import unittest
from database.database_manager import DatabaseManager
from services.auth_manager import AuthManager
from services.attendance_manager import AttendanceManager

class AttendanceSystemTests(unittest.TestCase):
    def setUp(self):
        handle, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(handle)
        self.db = DatabaseManager(self.db_path)
        self.auth = AuthManager(self.db)
        self.auth.create_user("worker1", "Test Worker", "password123", "employee")
        self.user = self.auth.login("worker1", "password123")
        self.attendance = AttendanceManager(self.db)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_employee_login(self):
        self.assertIsNotNone(self.user)
        self.assertEqual(self.user.dashboard_type, "Employee")

    def test_wrong_password_rejected(self):
        self.assertIsNone(self.auth.login("worker1", "wrongpass"))

    def test_duplicate_username_rejected(self):
        with self.assertRaises(ValueError):
            self.auth.create_user("worker1", "Another Worker", "password123", "employee")

    def test_time_in_creates_open_record(self):
        self.attendance.time_in(self.user.user_id)
        self.assertIsNotNone(self.attendance.get_open_record(self.user.user_id))

    def test_duplicate_time_in_rejected(self):
        self.attendance.time_in(self.user.user_id)
        with self.assertRaises(ValueError):
            self.attendance.time_in(self.user.user_id)

    def test_time_out_without_time_in_rejected(self):
        with self.assertRaises(ValueError):
            self.attendance.time_out(self.user.user_id)

if __name__ == "__main__":
    unittest.main()
